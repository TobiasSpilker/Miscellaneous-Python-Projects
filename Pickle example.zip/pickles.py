if __name__ == "__main__":

    import type_counter
    import nltk
    import pickle
    
    def make_and_pickle(corpus, path, tagset=None):
        objectje = type_counter.TagTypes(corpus, tagset)

        output = open(path, "wb")
        pickle.dump(objectje, output)
        output.close()
        
        
    def unpickle(path):
        input = open(path, "rb")
        unpickled_object = pickle.load(input)
        input.close()    
        return unpickled_object